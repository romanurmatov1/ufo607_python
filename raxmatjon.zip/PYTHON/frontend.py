from tkinter import *
import backend

def get_selected_row(event):
    global selected_row
    index = list.curselection()[0]
    selected_row = list.get(index)
    e1.delete(0,END)
    e1.insert(END,selected_row[1])
    e2.delete(0,END)
    e2.insert(END,selected_row[2])
    e3.delete(0,END)
    e3.insert(END,selected_row[3])
    e4.delete(0,END)
    e4.insert(END,selected_row[4])
    e5.delete(0,END)
    e5.insert(END,selected_row[5])
    e6.delete(0,END)
    e6.insert(END,selected_row[6])

def delete_command():
    backend.delete(selected_row[0])
    view_command()

def view_command():
    list.delete(0,END)
    for row in backend.view():
        list.insert(END,row)

def search_command():
    list.delete(0,END)
    for row in backend.search(date_text.get(),earning_text.get(),exercise_text.get(),study_text.get(),diet_text.get(),python_text.get()):
        list.insert(END,row)

def add_command():
    date = date_text.get()
    earning = earning_text.get()
    exercise = exercise_text.get()
    emailt = diet_text.get()
    study = study_text.get()
    pytext = python_text.get()
    a = date[0:2]
    a1 = str(date[2:3])
    b = date[3:5]
    b1 = str(date[2:3])
    c = date[6:12]
    if a.isnumeric() != True or int(a) not in range(1,13) or a1 != '-' or b.isnumeric() != True or int(b) not in range(1,32) or b1 != '-' or c.isnumeric() != True or int(c) <= 0:
        list.insert(0, 'Date Format Xato! {mm-dd-yyyy}')
    elif earning.isnumeric() == False or 0 > int(earning) > 9999:
        list.insert(0,'Earnings xato! {earning numeric min=0 & max=9999}')
    elif exercise.isalpha() == False or len(exercise) < 10 or len(exercise) > 50:
        list.insert(0,'Exercise xato! {exercise string & len min=10 & max=50}')
    elif emailt.find('@') not in range(1, len(emailt)) or emailt.find('.') not in range(1, len(emailt)) or emailt[emailt.find('@')+1:emailt.find('.')] != 'gmail' and emailt[emailt.find('@')+1:emailt.find('.')] != 'hotmail' or emailt[emailt.find('.')+1:emailt.find('.')+4] != 'com':
        list.insert(0, 'Email xato! {gmail or hotmail and com')
    elif study.isalpha() == False or len(study) < 10 or len(study) > 50:
        list.insert(0,'Study xato! {Study string & len min=10 & max=50}')
    elif pytext.isupper() == False or len(pytext) < 5 or len(pytext)>10:
        list.insert(0,'Python xato! {Python upper & len min=5 & max=10}')
    else:
        backend.insert(date_text.get(),earning_text.get(),exercise_text.get(),study_text.get(),diet_text.get(),python_text.get())
        list.delete(0, END)
        list.insert(END, (
        date_text.get(), earning_text.get(), exercise_text.get(), study_text.get(), diet_text.get(), python_text.get()))

win = Tk()
win.configure(bg='linen')

win.wm_title('MY ROUTINE DATABASE')

l1 = Label(win, text='Date')
l1.configure(bg='pale green')
l1.grid(row=0,column=0)
l2 = Label(win, text='Earnings')
l2.configure(bg='pale green')
l2.grid(row=0,column=2)
l3 = Label(win, text='Exercise')
l3.configure(bg='pale green')
l3.configure(bg='pale green')
l3.grid(row=1,column=0)
l4 = Label(win, text='Study')
l4.configure(bg='pale green')
l4.grid(row=1,column=2)
l5 = Label(win, text='Email')
l5.configure(bg='pale green')

l5.grid(row=2,column=0)
l6 = Label(win, text='Python')
l6.configure(bg='pale green')

l6.grid(row=2,column=2)

date_text = StringVar()
e1 = Entry(win, textvariable=date_text, width=40)
e1.insert(0, 'just "mm-dd-yyyy"')
e1.grid(row=0,column=1)

earning_text = StringVar()
e2 = Entry(win, textvariable=earning_text, width=40)
e2.insert(0, 'just numeric {min=0 & max=9999}')
e2.grid(row=0,column=3)

exercise_text = StringVar()
e3 = Entry(win, textvariable=exercise_text, width=40)
e3.insert(0,'just string alpha {len -> min=10 & max=50}')
e3.grid(row=1,column=1)

study_text = StringVar()
e4 = Entry(win, textvariable=study_text, width=40)
e4.insert(0, 'just string alpha {len -> min=10 & max=50}')
e4.grid(row=1,column=3)

diet_text = StringVar()
e5 = Entry(win, textvariable=diet_text, width=40)
e5.insert(0, 'just gmail or hotmail and .com')
e5.grid(row=2,column=1)

python_text = StringVar()
e6 = Entry(win, textvariable=python_text, width=40)
e6.insert(0,'just upper {len -> min=5 & max=10}')
e6.grid(row=2,column=3)

list = Listbox(win,height=8,width=50)
list.grid(row=3,column=0,rowspan=9,columnspan=2)

sb = Scrollbar(win)
sb.grid(row=3,column=2,rowspan=9)

list.bind('<<ListboxSelect>>',get_selected_row)

b1 = Button(win,text='ADD',width=12,pady=5,command=add_command)
b1.grid(row=3,column=3)

b2 = Button(win,text='Search',width=12,pady=5,command=search_command)
b2.grid(row=4,column=3)

b3 = Button(win,text='Delete date',width=12,pady=5,command=delete_command)
b3.grid(row=5,column=3)

b4 = Button(win,text='View all',width=12,pady=5,command=view_command)
b4.grid(row=6,column=3)

b5 = Button(win,text='Close',width=12,pady=5,command = win.destroy)
b5.grid(row=7,column=3)

b1.configure(bg='tan')
b2.configure(bg='tan')
b3.configure(bg='tan')
b4.configure(bg='tan')
b5.configure(bg='tan')

win.mainloop()
